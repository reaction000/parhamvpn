# Parham VPN — architecture & developer notes

Native Kotlin Android VPN **client** (no servers provided). XML layouts, Persian RTL UI, dark-first theme.

**Status: source only. Never compiled, never tested, no APK, no libXray AAR.** See `BUILD_NOTES.md`.

## Architecture
- `parser/` — `LinkParser` (share links), `SubscriptionDecoder` / `SubscriptionFetcher` (HTTPS only, 2 MB cap, no http redirects, Base64 + strict UTF-8 check).
- `engine/` — `XrayEngine` interface, `LibXrayEngine` (reflection over `libXray.LibXray`, so the app builds without the AAR), `XrayConfigBuilder` (Xray JSON: TUN inbound + `proxy` outbound).
- `vpn/` — `ParhamVpnService` (`:vpn` process, foreground, notification with Disconnect, `onRevoke`), `VpnState` (broadcast protocol with the UI).
- `data/` — `SecureStore` (EncryptedSharedPreferences, falls back to plain private prefs and says so), `ServerRepository`, `AppSettings`.
- `ui/` — Splash, Main (connect), Servers, AddServer, Subscriptions, Settings, About.
- `util/` — `Redactor`, `AppLog` (local, redacted, clearable), `Base64Util`.

## Supported share links (what the parser accepts; the core may still reject at runtime)
| Scheme | Accepted |
|---|---|
| `vless://` | UUID user, `encryption=none`; type tcp/ws/grpc/xhttp(splithttp)/httpupgrade; security none/tls/reality (needs `pbk`); sni, fp, alpn, path, host, serviceName, mode, flow, sid, spx |
| `vmess://` | legacy Base64-JSON (aid must be 0) and AEAD URI style `vmess://uuid@host:port?...`; ciphers auto/aes-128-gcm/chacha20-poly1305/none/zero; tcp/ws/grpc/xhttp/httpupgrade; none/tls |
| `trojan://` | password, default TLS, same transports |
| `ss://` | SIP002 and legacy; aes-128/256-gcm, chacha20-ietf-poly1305, 2022-blake3-*; **no plugins** |
| `socks://`, `socks5://` | optional user:pass (plain or Base64) — SOCKS is unencrypted |
| Rejected with Persian errors | kcp/quic/h2, headerType≠none, allowInsecure, Hysteria2, SS plugins, non-zero alterId |

## Design decisions
- **Process split + kill:** TUN fd is passed to Go through an env var read at library init, so each session runs in a fresh `:vpn` process that is killed on stop.
- **Loop prevention:** app excluded via `addDisallowedApplication`; `protect()` not wired (no verified hook).
- **Never weaken TLS:** `allowInsecure` always false; links requesting it are rejected.
- Config handed to the service by Intent extra (same app, non-exported); the service does not read the store.
- Telegram icon: `assets/telegram_channel.svg` is shipped, but rendering uses the matching `drawable/ic_telegram.xml` (no SVG library).

## Tests (written, not run)
`LinkParserTest`, `SubscriptionDecoderTest`, `XrayConfigBuilderTest`, `RedactorTest` under `app/src/test`.

## File tree
```
.github/workflows/build-libxray-aar.yml
.gitignore
BUILD_NOTES.md
DEPENDENCIES_AND_LICENSES.md
README_EN.md
README_FA.md
app/build.gradle.kts
app/libs/README.txt
app/proguard-rules.pro
app/src/main/AndroidManifest.xml
app/src/main/assets/telegram_channel.svg
app/src/main/java/com/parhamvpn/app/ParhamApp.kt
app/src/main/java/com/parhamvpn/app/data/AppSettings.kt
app/src/main/java/com/parhamvpn/app/data/SecureStore.kt
app/src/main/java/com/parhamvpn/app/data/ServerRepository.kt
app/src/main/java/com/parhamvpn/app/engine/LibXrayEngine.kt
app/src/main/java/com/parhamvpn/app/engine/XrayConfigBuilder.kt
app/src/main/java/com/parhamvpn/app/engine/XrayEngine.kt
app/src/main/java/com/parhamvpn/app/model/Models.kt
app/src/main/java/com/parhamvpn/app/parser/LinkParser.kt
app/src/main/java/com/parhamvpn/app/parser/SubscriptionDecoder.kt
app/src/main/java/com/parhamvpn/app/ui/AboutActivity.kt
app/src/main/java/com/parhamvpn/app/ui/AddServerActivity.kt
app/src/main/java/com/parhamvpn/app/ui/MainActivity.kt
app/src/main/java/com/parhamvpn/app/ui/ServersActivity.kt
app/src/main/java/com/parhamvpn/app/ui/SettingsActivity.kt
app/src/main/java/com/parhamvpn/app/ui/SplashActivity.kt
app/src/main/java/com/parhamvpn/app/ui/SubscriptionsActivity.kt
app/src/main/java/com/parhamvpn/app/ui/UiUtil.kt
app/src/main/java/com/parhamvpn/app/util/AppLog.kt
app/src/main/java/com/parhamvpn/app/util/Base64Util.kt
app/src/main/java/com/parhamvpn/app/util/Redactor.kt
app/src/main/java/com/parhamvpn/app/vpn/ParhamVpnService.kt
app/src/main/java/com/parhamvpn/app/vpn/VpnState.kt
app/src/main/res/drawable/bg_card.xml
app/src/main/res/drawable/bg_card_selected.xml
app/src/main/res/drawable/bg_connect_idle.xml
app/src/main/res/drawable/bg_connect_on.xml
app/src/main/res/drawable/bg_input.xml
app/src/main/res/drawable/bg_ring.xml
app/src/main/res/drawable/ic_launcher_foreground.xml
app/src/main/res/drawable/ic_logo.xml
app/src/main/res/drawable/ic_logo_small.xml
app/src/main/res/drawable/ic_telegram.xml
app/src/main/res/drawable/splash.xml
app/src/main/res/layout/activity_about.xml
app/src/main/res/layout/activity_add.xml
app/src/main/res/layout/activity_list.xml
app/src/main/res/layout/activity_main.xml
app/src/main/res/layout/activity_settings.xml
app/src/main/res/layout/item_server.xml
app/src/main/res/layout/item_sub.xml
app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml
app/src/main/res/values-night/bools.xml
app/src/main/res/values-night/colors.xml
app/src/main/res/values/bools.xml
app/src/main/res/values/colors.xml
app/src/main/res/values/strings.xml
app/src/main/res/values/themes.xml
app/src/test/java/com/parhamvpn/app/engine/XrayConfigBuilderTest.kt
app/src/test/java/com/parhamvpn/app/parser/LinkParserTest.kt
app/src/test/java/com/parhamvpn/app/parser/SubscriptionDecoderTest.kt
app/src/test/java/com/parhamvpn/app/util/RedactorTest.kt
build.gradle.kts
gradle.properties
gradle/wrapper/gradle-wrapper.properties
settings.gradle.kts
```

## Files you must add yourself
- `app/libs/libXray.aar` — build via `.github/workflows/build-libxray-aar.yml` (source https://github.com/XTLS/libXray). Optional for compiling, required for a working VPN.
