# Dependencies and licenses

All versions are pinned in `app/build.gradle.kts` / `build.gradle.kts`. Nothing here was downloaded or
resolved in the authoring environment (no network): versions are those I intended, **not verified to resolve
together** until you run a Gradle sync.

| Component | Version | Source | License |
|---|---|---|---|
| Android Gradle Plugin | 8.1.4 | https://maven.google.com | Apache-2.0 |
| Kotlin Gradle plugin | 1.9.10 | https://kotlinlang.org | Apache-2.0 |
| Gradle (wrapper properties only) | 8.4 | https://services.gradle.org | Apache-2.0 |
| androidx.core:core-ktx | 1.12.0 | https://maven.google.com | Apache-2.0 |
| androidx.appcompat:appcompat | 1.6.1 | https://maven.google.com | Apache-2.0 |
| com.google.android.material:material | 1.11.0 | https://maven.google.com | Apache-2.0 |
| androidx.constraintlayout:constraintlayout | 2.1.4 | https://maven.google.com | Apache-2.0 |
| androidx.recyclerview:recyclerview | 1.3.2 | https://maven.google.com | Apache-2.0 |
| androidx.lifecycle:lifecycle-runtime-ktx | 2.6.2 | https://maven.google.com | Apache-2.0 |
| org.jetbrains.kotlinx:kotlinx-coroutines-android | 1.7.3 | https://maven.org | Apache-2.0 |
| androidx.security:security-crypto | 1.1.0-alpha06 (alpha!) | https://maven.google.com | Apache-2.0 |
| com.google.zxing:core | 3.5.2 | https://github.com/zxing/zxing | Apache-2.0 |
| junit:junit (test) | 4.13.2 | https://junit.org | EPL-1.0 |
| org.json:json (test) | 20231013 | https://github.com/stleary/JSON-java | JSON License |

## Xray / libXray (NOT included)

| Item | Value |
|---|---|
| Wrapper | XTLS/libXray — https://github.com/XTLS/libXray |
| Core | XTLS/Xray-core — https://github.com/XTLS/Xray-core |
| Expected file | `app/libs/libXray.aar` |
| libXray version / tag | **not pinned — no AAR was obtained.** You choose the tag when running the workflow and must record it here |
| Xray-core version | whatever the chosen libXray tag vendors; read it from About screen once installed |
| ABIs | whatever the build produces (record with `unzip -l libXray.aar`) |
| SHA-256 | **none — no AAR exists in this ZIP.** Record yours: `sha256sum app/libs/libXray.aar` |
| License | Both projects are MPL-2.0 (confirm in the upstream repos at your chosen tag) |

No AAR, APK, checksum or download URL beyond the two repository URLs above was invented.
