package com.parhamvpn.app.parser

import org.junit.Assert.assertEquals
import org.junit.Assert.fail
import org.junit.Test
import java.util.Base64

class SubscriptionDecoderTest {
    private val uuid = "11111111-1111-1111-1111-111111111111"
    private fun b64(b: ByteArray) = Base64.getEncoder().encodeToString(b)
    private fun fails(body: String) {
        try { SubscriptionDecoder.parseBody(body) } catch (e: ParseException) { return }
        fail("expected ParseException")
    }

    @Test fun plainText() {
        val r = SubscriptionDecoder.parseBody("vless://$uuid@a.com:443?security=none\ntrojan://p@b.com:443")
        assertEquals(2, r.servers.size)
    }

    @Test fun base64Wrapped() {
        val text = "vless://$uuid@a.com:443?security=none\ntrojan://p@b.com:443\n"
        assertEquals(2, SubscriptionDecoder.parseBody(b64(text.toByteArray())).servers.size)
    }

    @Test fun rejectsEmptyGarbageAndNonUtf8() {
        fails("")
        fails("   ")
        fails("!!!not base64!!!")
        fails(b64(byteArrayOf(0xff.toByte(), 0xfe.toByte(), 0xfd.toByte(), 0x80.toByte())))
        fails(b64("hello world".toByteArray()))          // valid base64, but not a subscription
    }

    @Test fun allLinesInvalidIsAnError() {
        fails("vless://bad@x.com:443\nvmess://zzz")
    }
}
