package com.parhamvpn.app.engine

import com.parhamvpn.app.parser.LinkParser
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test

class XrayConfigBuilderTest {
    private val uuid = "11111111-1111-1111-1111-111111111111"

    @Test fun realityOutbound() {
        val s = LinkParser.parse("vless://$uuid@1.2.3.4:443?type=tcp&security=reality&pbk=PUB&sid=01&fp=chrome&sni=x.com&flow=xtls-rprx-vision")
        val root = JSONObject(XrayConfigBuilder.build(s))
        assertEquals("tun", root.getJSONArray("inbounds").getJSONObject(0).getString("protocol"))
        val out = root.getJSONArray("outbounds").getJSONObject(0)
        assertEquals("proxy", out.getString("tag"))
        assertEquals("vless", out.getString("protocol"))
        val st = out.getJSONObject("streamSettings")
        assertEquals("reality", st.getString("security"))
        assertEquals("PUB", st.getJSONObject("realitySettings").getString("publicKey"))
        val user = out.getJSONObject("settings").getJSONArray("vnext").getJSONObject(0).getJSONArray("users").getJSONObject(0)
        assertEquals("xtls-rprx-vision", user.getString("flow"))
    }

    @Test fun tlsNeverAllowsInsecure() {
        val s = LinkParser.parse("trojan://pw@example.com:443?sni=example.com")
        val st = JSONObject(XrayConfigBuilder.build(s)).getJSONArray("outbounds").getJSONObject(0).getJSONObject("streamSettings")
        assertFalse(st.getJSONObject("tlsSettings").getBoolean("allowInsecure"))
        assertEquals("example.com", st.getJSONObject("tlsSettings").getString("serverName"))
    }

    @Test fun shadowsocksHasNoStreamSettings() {
        val s = LinkParser.parse("ss://" + java.util.Base64.getEncoder().encodeToString("aes-256-gcm:pw".toByteArray()) + "@1.2.3.4:8388")
        val out = JSONObject(XrayConfigBuilder.build(s)).getJSONArray("outbounds").getJSONObject(0)
        assertEquals("shadowsocks", out.getString("protocol"))
        assertFalse(out.has("streamSettings"))
    }

    @Test fun wsSettings() {
        val s = LinkParser.parse("vless://$uuid@h.com:443?type=ws&security=tls&path=%2Fp&host=cdn.com")
        val ws = JSONObject(XrayConfigBuilder.build(s)).getJSONArray("outbounds").getJSONObject(0)
            .getJSONObject("streamSettings").getJSONObject("wsSettings")
        assertEquals("/p", ws.getString("path"))
        assertEquals("cdn.com", ws.getJSONObject("headers").getString("Host"))
    }
}
