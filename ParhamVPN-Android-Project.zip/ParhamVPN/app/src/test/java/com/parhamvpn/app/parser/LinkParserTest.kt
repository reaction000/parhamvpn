package com.parhamvpn.app.parser

import com.parhamvpn.app.model.Protocol
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.util.Base64

class LinkParserTest {
    private val uuid = "11111111-1111-1111-1111-111111111111"
    private fun b64(s: String) = Base64.getEncoder().encodeToString(s.toByteArray())
    private fun fails(link: String) {
        try { LinkParser.parse(link) } catch (e: ParseException) { return }
        fail("expected ParseException for: $link")
    }

    @Test fun vlessWsTls() {
        val s = LinkParser.parse("vless://$uuid@example.com:443?type=ws&security=tls&sni=example.com&path=%2Fws&host=cdn.example.com#My%20Server")
        assertEquals(Protocol.VLESS, s.protocol)
        assertEquals("example.com", s.host)
        assertEquals(443, s.port)
        assertEquals("My Server", s.name)
        assertEquals("ws", s.params["network"])
        assertEquals("tls", s.params["security"])
        assertEquals("/ws", s.params["path"])
        assertEquals("cdn.example.com", s.params["host"])
    }

    @Test fun vlessReality() {
        val s = LinkParser.parse("vless://$uuid@1.2.3.4:443?type=tcp&security=reality&pbk=PUBKEY&sid=01ab&fp=chrome&sni=x.com&flow=xtls-rprx-vision#R")
        assertEquals("reality", s.params["security"])
        assertEquals("PUBKEY", s.params["pbk"])
        assertEquals("xtls-rprx-vision", s.params["flow"])
    }

    @Test fun vlessGrpcAndXhttp() {
        assertEquals("grpc", LinkParser.parse("vless://$uuid@h.com:443?type=grpc&serviceName=svc&security=tls").params["network"])
        assertEquals("xhttp", LinkParser.parse("vless://$uuid@h.com:443?type=splithttp&security=tls&path=%2Fx").params["network"])
    }

    @Test fun vlessIpv6() {
        val s = LinkParser.parse("vless://$uuid@[2001:db8::1]:8443?security=none")
        assertEquals("2001:db8::1", s.host)
        assertEquals(8443, s.port)
    }

    @Test fun vlessRejectsBadInput() {
        fails("vless://not-a-uuid@example.com:443")
        fails("vless://$uuid@example.com")                       // no port
        fails("vless://$uuid@example.com:70000")                 // port range
        fails("vless://$uuid@example.com:443?security=reality")  // missing pbk
        fails("vless://$uuid@example.com:443?allowInsecure=1&security=tls")
        fails("vless://$uuid@example.com:443?type=kcp")
        fails("vless://$uuid@example.com:443?encryption=aes")
        fails("vless://@example.com:443")
    }

    @Test fun genericBadInput() {
        fails("")
        fails("hello")
        fails("http://example.com")
        fails("hysteria2://pass@example.com:443")
    }

    @Test fun vmessLegacy() {
        val json = """{"v":"2","ps":"test","add":"1.2.3.4","port":"443","id":"$uuid","aid":"0","scy":"auto","net":"ws","type":"none","host":"h.com","path":"/p","tls":"tls","sni":"s.com"}"""
        val s = LinkParser.parse("vmess://" + b64(json))
        assertEquals(Protocol.VMESS, s.protocol)
        assertEquals("test", s.name)
        assertEquals("1.2.3.4", s.host)
        assertEquals(443, s.port)
        assertEquals("ws", s.params["network"])
        assertEquals("tls", s.params["security"])
        assertEquals("/p", s.params["path"])
    }

    @Test fun vmessRejectsLegacyAlterId() {
        val json = """{"add":"1.2.3.4","port":443,"id":"$uuid","aid":4,"net":"tcp"}"""
        fails("vmess://" + b64(json))
    }

    @Test fun vmessBadBase64AndJson() {
        fails("vmess://!!!")
        fails("vmess://" + b64("not json"))
        fails("vmess://" + b64("""{"add":"","port":1,"id":"$uuid"}"""))
    }

    @Test fun vmessAeadUri() {
        val s = LinkParser.parse("vmess://$uuid@example.com:443?encryption=aes-128-gcm&security=tls&type=tcp#V")
        assertEquals("aes-128-gcm", s.params["cipher"])
        assertEquals("V", s.name)
    }

    @Test fun trojanDefaultsToTls() {
        val s = LinkParser.parse("trojan://pass123@example.com:443?sni=example.com#T")
        assertEquals(Protocol.TROJAN, s.protocol)
        assertEquals("pass123", s.secret)
        assertEquals("tls", s.params["security"])
    }

    @Test fun shadowsocksSip002() {
        val s = LinkParser.parse("ss://" + b64("aes-256-gcm:secret") + "@1.2.3.4:8388#SS")
        assertEquals(Protocol.SHADOWSOCKS, s.protocol)
        assertEquals("aes-256-gcm", s.params["method"])
        assertEquals("secret", s.secret)
        assertEquals(8388, s.port)
    }

    @Test fun shadowsocksLegacy() {
        val s = LinkParser.parse("ss://" + b64("aes-128-gcm:pw@5.6.7.8:1234") + "#L")
        assertEquals("5.6.7.8", s.host)
        assertEquals("pw", s.secret)
    }

    @Test fun shadowsocksRejects() {
        fails("ss://" + b64("rc4-md5:secret") + "@1.2.3.4:8388")
        fails("ss://" + b64("aes-256-gcm:secret") + "@1.2.3.4:8388?plugin=obfs-local")
        fails("ss://" + b64("aes-256-gcm"))
    }

    @Test fun socks() {
        val s = LinkParser.parse("socks5://user:pass@1.2.3.4:1080#S")
        assertEquals(Protocol.SOCKS, s.protocol)
        assertEquals("user", s.params["user"])
        assertEquals("pass", s.secret)
    }

    @Test fun parseManyCollectsErrors() {
        val r = LinkParser.parseMany("vless://$uuid@a.com:443?security=none\n\nbad-line\ntrojan://p@b.com:443")
        assertEquals(2, r.servers.size)
        assertEquals(1, r.errors.size)
        assertTrue(r.errors[0].startsWith("خط 3"))
    }
}
