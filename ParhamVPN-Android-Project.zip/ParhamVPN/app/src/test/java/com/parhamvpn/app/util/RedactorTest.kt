package com.parhamvpn.app.util

import org.junit.Assert.assertFalse
import org.junit.Test

class RedactorTest {
    @Test fun removesSecrets() {
        val t = Redactor.redact("id 11111111-1111-1111-1111-111111111111 link vless://u@h.com:443?x=1 password=abc123 https://sub.example/token/xyz")
        assertFalse(t.contains("11111111-1111"))
        assertFalse(t.contains("vless://"))
        assertFalse(t.contains("abc123"))
        assertFalse(t.contains("sub.example"))
    }
}
