package com.parhamvpn.app.ui

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.parhamvpn.app.R
import com.parhamvpn.app.engine.LibXrayEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AboutActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "?" } catch (e: Exception) { "?" }
        findViewById<TextView>(R.id.tvVersion).text = getString(R.string.app_version, ver)
        findViewById<android.view.View>(R.id.rowTelegram).setOnClickListener { MainActivity.openTelegram(this) }

        val tv = findViewById<TextView>(R.id.tvEngineInfo)
        val engine = LibXrayEngine()
        if (!engine.isAvailable()) {
            tv.text = getString(R.string.engine_status, getString(R.string.engine_unavailable))
        } else {
            tv.text = getString(R.string.engine_status, "…")
            lifecycleScope.launch {
                // Reading the version loads the native library in this process; keep it off the main thread.
                val v = withContext(Dispatchers.IO) { try { engine.version() } catch (t: Throwable) { null } }
                tv.text = getString(R.string.engine_status,
                    getString(R.string.engine_available, v ?: getString(R.string.engine_version_unknown)))
            }
        }
    }
}
