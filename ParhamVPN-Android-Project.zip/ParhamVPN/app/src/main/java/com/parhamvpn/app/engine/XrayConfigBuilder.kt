package com.parhamvpn.app.engine

import com.parhamvpn.app.model.Protocol
import com.parhamvpn.app.model.ServerConfig
import org.json.JSONArray
import org.json.JSONObject

/**
 * Builds the Xray JSON: one TUN inbound (fd handed over via env "xray.tun.fd" by the VPN service)
 * and one proxy outbound. UNVERIFIED against a real core build — the TUN inbound field names
 * ("name", "MTU") follow Xray docs from memory.
 */
object XrayConfigBuilder {
    private val ipv4 = Regex("^\\d{1,3}(\\.\\d{1,3}){3}$")

    fun build(s: ServerConfig): String {
        val root = JSONObject()
        root.put("log", JSONObject().put("loglevel", "warning"))
        root.put("inbounds", JSONArray().put(
            JSONObject().put("tag", "tun-in").put("protocol", "tun")
                .put("settings", JSONObject().put("name", "xray0").put("MTU", 1500))
        ))
        root.put("outbounds", JSONArray()
            .put(outbound(s))
            .put(JSONObject().put("tag", "direct").put("protocol", "freedom"))
            .put(JSONObject().put("tag", "block").put("protocol", "blackhole")))
        root.put("routing", JSONObject().put("domainStrategy", "AsIs").put("rules", JSONArray()))
        return root.toString()
    }

    fun outbound(s: ServerConfig): JSONObject {
        val o = JSONObject().put("tag", "proxy")
        when (s.protocol) {
            Protocol.VLESS -> o.put("protocol", "vless").put("settings", JSONObject().put("vnext", JSONArray().put(
                JSONObject().put("address", s.host).put("port", s.port).put("users", JSONArray().put(
                    JSONObject().put("id", s.secret).put("encryption", "none").apply {
                        s.params["flow"]?.let { put("flow", it) }
                    })))))
            Protocol.VMESS -> o.put("protocol", "vmess").put("settings", JSONObject().put("vnext", JSONArray().put(
                JSONObject().put("address", s.host).put("port", s.port).put("users", JSONArray().put(
                    JSONObject().put("id", s.secret).put("alterId", 0).put("security", s.params["cipher"] ?: "auto"))))))
            Protocol.TROJAN -> o.put("protocol", "trojan").put("settings", JSONObject().put("servers", JSONArray().put(
                JSONObject().put("address", s.host).put("port", s.port).put("password", s.secret))))
            Protocol.SHADOWSOCKS -> o.put("protocol", "shadowsocks").put("settings", JSONObject().put("servers", JSONArray().put(
                JSONObject().put("address", s.host).put("port", s.port)
                    .put("method", s.params["method"] ?: "aes-256-gcm").put("password", s.secret))))
            Protocol.SOCKS -> o.put("protocol", "socks").put("settings", JSONObject().put("servers", JSONArray().put(
                JSONObject().put("address", s.host).put("port", s.port).apply {
                    val u = s.params["user"]
                    if (!u.isNullOrEmpty()) put("users", JSONArray().put(JSONObject().put("user", u).put("pass", s.secret)))
                })))
        }
        if (s.protocol != Protocol.SHADOWSOCKS && s.protocol != Protocol.SOCKS) o.put("streamSettings", stream(s))
        return o
    }

    private fun isIp(h: String) = ipv4.matches(h) || h.contains(':')

    private fun stream(s: ServerConfig): JSONObject {
        val p = s.params
        val net = p["network"] ?: "tcp"
        val sec = p["security"] ?: "none"
        val st = JSONObject().put("network", net).put("security", sec)
        val hostHdr = p["host"].orEmpty()
        val sni = p["sni"] ?: hostHdr.ifEmpty { if (isIp(s.host)) "" else s.host }
        when (sec) {
            "tls" -> st.put("tlsSettings", JSONObject().apply {
                if (sni.isNotEmpty()) put("serverName", sni)
                p["fp"]?.let { put("fingerprint", it) }
                p["alpn"]?.let { put("alpn", JSONArray(it.split(',').map { a -> a.trim() }.filter { a -> a.isNotEmpty() })) }
                put("allowInsecure", false)
            })
            "reality" -> st.put("realitySettings", JSONObject()
                .put("serverName", sni).put("fingerprint", p["fp"] ?: "chrome")
                .put("publicKey", p["pbk"]).put("shortId", p["sid"] ?: "").put("spiderX", p["spx"] ?: ""))
        }
        when (net) {
            "ws" -> st.put("wsSettings", JSONObject().put("path", p["path"] ?: "/").apply {
                if (hostHdr.isNotEmpty()) put("headers", JSONObject().put("Host", hostHdr))
            })
            "grpc" -> st.put("grpcSettings", JSONObject().put("serviceName", p["serviceName"] ?: "").put("multiMode", p["mode"] == "multi"))
            "xhttp" -> st.put("xhttpSettings", JSONObject().put("path", p["path"] ?: "/").apply {
                if (hostHdr.isNotEmpty()) put("host", hostHdr)
                p["mode"]?.let { put("mode", it) }
            })
            "httpupgrade" -> st.put("httpupgradeSettings", JSONObject().put("path", p["path"] ?: "/").apply {
                if (hostHdr.isNotEmpty()) put("host", hostHdr)
            })
        }
        return st
    }
}
