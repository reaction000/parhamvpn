package com.parhamvpn.app.parser

import com.parhamvpn.app.model.ImportResult
import com.parhamvpn.app.model.Protocol
import com.parhamvpn.app.model.ServerConfig
import com.parhamvpn.app.util.Base64Util
import org.json.JSONException
import org.json.JSONObject
import java.net.URLDecoder
import java.util.UUID

class ParseException(message: String) : Exception(message)

/**
 * Supported share links (see README_EN.md):
 *  vless://, vmess:// (legacy base64-JSON and AEAD URI style), trojan://, ss:// (SIP002 + legacy), socks:// / socks5://.
 * Transports: tcp, ws, grpc, xhttp (alias splithttp), httpupgrade. Security: none, tls, reality.
 * Anything else is rejected with a Persian message instead of being silently accepted.
 */
object LinkParser {
    private val NETWORKS = setOf("tcp", "ws", "grpc", "xhttp", "httpupgrade")
    private val SECURITIES = setOf("none", "tls", "reality")
    private val VMESS_CIPHERS = setOf("auto", "aes-128-gcm", "chacha20-poly1305", "none", "zero")
    private val SS_METHODS = setOf(
        "aes-128-gcm", "aes-256-gcm", "chacha20-ietf-poly1305",
        "2022-blake3-aes-128-gcm", "2022-blake3-aes-256-gcm", "2022-blake3-chacha20-poly1305"
    )
    private val UUID_RE = Regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")

    fun parse(input: String): ServerConfig {
        val link = input.trim()
        if (link.isEmpty()) throw ParseException("لینک خالی است")
        val idx = link.indexOf("://")
        if (idx <= 0) throw ParseException("فرمت لینک نامعتبر است")
        return when (val scheme = link.substring(0, idx).lowercase()) {
            "vless" -> parseUriStyle(link, Protocol.VLESS)
            "trojan" -> parseUriStyle(link, Protocol.TROJAN)
            "vmess" -> parseVmess(link)
            "ss" -> parseSs(link)
            "socks", "socks5" -> parseSocks(link)
            "hysteria2", "hy2" -> throw ParseException("Hysteria2 در این نسخه پشتیبانی نمی‌شود")
            else -> throw ParseException("پروتکل پشتیبانی نمی‌شود: $scheme")
        }
    }

    fun parseMany(text: String): ImportResult {
        val servers = mutableListOf<ServerConfig>()
        val errors = mutableListOf<String>()
        text.lines().forEachIndexed { i, raw ->
            val line = raw.trim()
            if (line.isEmpty()) return@forEachIndexed
            try { servers += parse(line) } catch (e: ParseException) { errors += "خط ${i + 1}: ${e.message}" }
        }
        return ImportResult(servers, errors)
    }

    // ---------- helpers ----------

    private class Parts(val userInfo: String, val host: String, val port: Int, val query: Map<String, String>, val fragment: String)

    private fun decode(s: String): String = try {
        URLDecoder.decode(s.replace("+", "%2B"), "UTF-8")
    } catch (e: IllegalArgumentException) { s }

    private fun parseQuery(q: String): Map<String, String> {
        val m = mutableMapOf<String, String>()
        for (pair in q.split('&')) {
            if (pair.isEmpty()) continue
            val eq = pair.indexOf('=')
            val k = (if (eq >= 0) pair.substring(0, eq) else pair).lowercase()
            val v = if (eq >= 0) decode(pair.substring(eq + 1)) else ""
            m[k] = v
        }
        return m
    }

    private fun hostPort(hp: String): Pair<String, Int> {
        val host: String
        val portStr: String
        if (hp.startsWith("[")) {
            val end = hp.indexOf(']')
            if (end < 0) throw ParseException("آدرس IPv6 نامعتبر است")
            host = hp.substring(1, end)
            val after = hp.substring(end + 1)
            if (!after.startsWith(":")) throw ParseException("پورت مشخص نشده است")
            portStr = after.substring(1)
        } else {
            val c = hp.lastIndexOf(':')
            if (c < 0) throw ParseException("پورت مشخص نشده است")
            host = hp.substring(0, c)
            portStr = hp.substring(c + 1)
        }
        val port = portStr.toIntOrNull()
        if (port == null || port !in 1..65535) throw ParseException("پورت نامعتبر است")
        if (host.isEmpty() || host.any { it.isWhitespace() }) throw ParseException("آدرس سرور نامعتبر است")
        return host to port
    }

    private fun split(link: String): Parts {
        var rest = link.substring(link.indexOf("://") + 3)
        var fragment = ""
        val h = rest.indexOf('#')
        if (h >= 0) { fragment = decode(rest.substring(h + 1)); rest = rest.substring(0, h) }
        var query = emptyMap<String, String>()
        val qi = rest.indexOf('?')
        if (qi >= 0) { query = parseQuery(rest.substring(qi + 1)); rest = rest.substring(0, qi) }
        rest = rest.trimEnd('/')
        val at = rest.lastIndexOf('@')
        val userInfo = if (at >= 0) rest.substring(0, at) else ""
        val (host, port) = hostPort(if (at >= 0) rest.substring(at + 1) else rest)
        return Parts(userInfo, host, port, query, fragment)
    }

    private fun transport(q: Map<String, String>, defaultSecurity: String): Map<String, String> {
        val out = mutableMapOf<String, String>()
        var net = (q["type"] ?: "").lowercase().ifEmpty { "tcp" }
        if (net == "splithttp") net = "xhttp"
        if (net !in NETWORKS) throw ParseException("نوع انتقال پشتیبانی نمی‌شود: $net")
        out["network"] = net
        val ht = q["headertype"].orEmpty()
        if (ht.isNotEmpty() && ht != "none") throw ParseException("headerType پشتیبانی نمی‌شود: $ht")
        val sec = (q["security"] ?: "").lowercase().ifEmpty { defaultSecurity }
        if (sec !in SECURITIES) throw ParseException("نوع امنیت پشتیبانی نمی‌شود: $sec")
        out["security"] = sec
        if (q["allowinsecure"] == "1" || q["allowinsecure"] == "true" || q["insecure"] == "1")
            throw ParseException("allowInsecure به‌دلایل امنیتی پشتیبانی نمی‌شود")
        for (k in listOf("sni", "fp", "alpn", "path", "host", "mode", "flow", "pbk", "sid", "spx")) {
            q[k]?.takeIf { it.isNotEmpty() }?.let { out[k] = it }
        }
        q["servicename"]?.takeIf { it.isNotEmpty() }?.let { out["serviceName"] = it }
        if (sec == "reality" && out["pbk"].isNullOrEmpty()) throw ParseException("پارامتر pbk برای Reality الزامی است")
        return out
    }

    private fun newId() = UUID.randomUUID().toString()
    private fun label(name: String, host: String, port: Int) = name.ifBlank { "$host:$port" }

    // ---------- VLESS / Trojan ----------

    private fun parseUriStyle(link: String, protocol: Protocol): ServerConfig {
        val p = split(link)
        val secret = decode(p.userInfo)
        if (secret.isEmpty()) throw ParseException(if (protocol == Protocol.VLESS) "شناسه (UUID) وجود ندارد" else "رمز عبور وجود ندارد")
        if (protocol == Protocol.VLESS) {
            if (!UUID_RE.matches(secret)) throw ParseException("UUID نامعتبر است")
            val enc = p.query["encryption"].orEmpty()
            if (enc.isNotEmpty() && enc != "none") throw ParseException("encryption پشتیبانی نمی‌شود: $enc")
        }
        val params = transport(p.query, if (protocol == Protocol.TROJAN) "tls" else "none")
        return ServerConfig(newId(), label(p.fragment, p.host, p.port), protocol, p.host, p.port, secret, params, link)
    }

    // ---------- VMess ----------

    private fun parseVmess(link: String): ServerConfig {
        val body = link.substring("vmess://".length)
        val beforeFragment = body.substringBefore('#')
        if (beforeFragment.contains('@')) {
            val p = split(link)
            val id = decode(p.userInfo)
            if (!UUID_RE.matches(id)) throw ParseException("UUID نامعتبر است")
            val cipher = (p.query["encryption"] ?: p.query["scy"] ?: "auto").lowercase().ifEmpty { "auto" }
            if (cipher !in VMESS_CIPHERS) throw ParseException("رمزنگاری VMess پشتیبانی نمی‌شود: $cipher")
            val params = transport(p.query, "none").toMutableMap()
            params["cipher"] = cipher
            return ServerConfig(newId(), label(p.fragment, p.host, p.port), Protocol.VMESS, p.host, p.port, id, params, link)
        }
        val json = Base64Util.decodeToString(beforeFragment) ?: throw ParseException("Base64 لینک VMess نامعتبر است")
        val o = try { JSONObject(json) } catch (e: JSONException) { throw ParseException("JSON لینک VMess نامعتبر است") }
        val host = o.optString("add").trim()
        val port = o.optString("port").trim().toIntOrNull()
        val id = o.optString("id").trim()
        if (host.isEmpty() || host.any { it.isWhitespace() }) throw ParseException("آدرس سرور نامعتبر است")
        if (port == null || port !in 1..65535) throw ParseException("پورت نامعتبر است")
        if (!UUID_RE.matches(id)) throw ParseException("UUID نامعتبر است")
        val aid = o.optString("aid").trim()
        if (aid.isNotEmpty() && aid != "0") throw ParseException("alterId غیرصفر (VMess قدیمی) پشتیبانی نمی‌شود")
        val cipher = o.optString("scy").trim().lowercase().ifEmpty { "auto" }
        if (cipher !in VMESS_CIPHERS) throw ParseException("رمزنگاری VMess پشتیبانی نمی‌شود: $cipher")
        val q = mutableMapOf<String, String>()
        q["type"] = o.optString("net").ifEmpty { "tcp" }
        q["headertype"] = o.optString("type")
        val tls = o.optString("tls").lowercase()
        q["security"] = when (tls) { "", "none" -> "none"; "tls" -> "tls"; else -> throw ParseException("مقدار tls نامعتبر است") }
        q["sni"] = o.optString("sni")
        q["alpn"] = o.optString("alpn")
        q["fp"] = o.optString("fp")
        q["host"] = o.optString("host")
        if (q["type"] == "grpc") q["servicename"] = o.optString("path") else q["path"] = o.optString("path")
        val params = transport(q, "none").toMutableMap()
        params["cipher"] = cipher
        return ServerConfig(newId(), label(o.optString("ps"), host, port), Protocol.VMESS, host, port, id, params, link)
    }

    // ---------- Shadowsocks ----------

    private fun parseSs(link: String): ServerConfig {
        var rest = link.substring("ss://".length)
        var name = ""
        val h = rest.indexOf('#')
        if (h >= 0) { name = decode(rest.substring(h + 1)); rest = rest.substring(0, h) }
        val qi = rest.indexOf('?')
        if (qi >= 0) {
            val q = parseQuery(rest.substring(qi + 1))
            if (q.containsKey("plugin")) throw ParseException("افزونه (plugin) شدوساکس پشتیبانی نمی‌شود")
            rest = rest.substring(0, qi)
        }
        rest = rest.trimEnd('/')
        val methodPass: String
        val host: String
        val port: Int
        val at = rest.lastIndexOf('@')
        if (at >= 0) {
            val ui = rest.substring(0, at)
            methodPass = if (ui.contains(':')) decode(ui)
            else Base64Util.decodeToString(ui) ?: throw ParseException("Base64 اطلاعات کاربری نامعتبر است")
            val hp = hostPort(rest.substring(at + 1)); host = hp.first; port = hp.second
        } else {
            val dec = Base64Util.decodeToString(rest) ?: throw ParseException("Base64 لینک Shadowsocks نامعتبر است")
            val a = dec.lastIndexOf('@')
            if (a < 0) throw ParseException("لینک Shadowsocks ناقص است")
            methodPass = dec.substring(0, a)
            val hp = hostPort(dec.substring(a + 1)); host = hp.first; port = hp.second
        }
        val c = methodPass.indexOf(':')
        if (c <= 0 || c == methodPass.length - 1) throw ParseException("روش یا رمز عبور Shadowsocks وجود ندارد")
        val method = methodPass.substring(0, c).lowercase()
        if (method !in SS_METHODS) throw ParseException("روش رمزنگاری پشتیبانی نمی‌شود: $method")
        return ServerConfig(newId(), label(name, host, port), Protocol.SHADOWSOCKS, host, port,
            methodPass.substring(c + 1), mapOf("method" to method), link)
    }

    // ---------- SOCKS ----------

    private fun parseSocks(link: String): ServerConfig {
        val p = split(link)
        var user = ""
        var pass = ""
        if (p.userInfo.isNotEmpty()) {
            val ui = if (p.userInfo.contains(':')) decode(p.userInfo)
            else Base64Util.decodeToString(p.userInfo) ?: throw ParseException("اطلاعات کاربری SOCKS نامعتبر است")
            val c = ui.indexOf(':')
            if (c < 0) throw ParseException("اطلاعات کاربری SOCKS نامعتبر است")
            user = ui.substring(0, c); pass = ui.substring(c + 1)
        }
        val params = if (user.isNotEmpty()) mapOf("user" to user) else emptyMap()
        return ServerConfig(newId(), label(p.fragment, p.host, p.port), Protocol.SOCKS, p.host, p.port, pass, params, link)
    }
}
