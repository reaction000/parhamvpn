package com.parhamvpn.app.data

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate

class AppSettings(ctx: Context) {
    private val p = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var theme: String
        get() = p.getString("theme", "dark") ?: "dark"
        set(v) { p.edit().putString("theme", v).apply() }

    var dns: String
        get() = p.getString("dns", "cloudflare") ?: "cloudflare"
        set(v) { p.edit().putString("dns", v).apply() }

    var customDns: String
        get() = p.getString("custom_dns", "") ?: ""
        set(v) { p.edit().putString("custom_dns", v).apply() }

    fun nightMode(): Int = when (theme) {
        "light" -> AppCompatDelegate.MODE_NIGHT_NO
        "system" -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        else -> AppCompatDelegate.MODE_NIGHT_YES
    }

    /** IPv4 DNS servers handed to the VPN interface. Falls back to Cloudflare if custom is invalid. */
    fun dnsServers(): ArrayList<String> {
        val list = when (dns) {
            "google" -> listOf("8.8.8.8", "8.8.4.4")
            "quad9" -> listOf("9.9.9.9", "149.112.112.112")
            "custom" -> parseDns(customDns).ifEmpty { listOf("1.1.1.1", "1.0.0.1") }
            else -> listOf("1.1.1.1", "1.0.0.1")
        }
        return ArrayList(list)
    }

    companion object {
        private val ipv4 = Regex("^((25[0-5]|2[0-4]\\d|1?\\d?\\d)\\.){3}(25[0-5]|2[0-4]\\d|1?\\d?\\d)$")
        fun parseDns(text: String): List<String> =
            text.split(',', ' ', ';', '\n').map { it.trim() }.filter { it.isNotEmpty() }.filter { ipv4.matches(it) }.take(3)
    }
}
