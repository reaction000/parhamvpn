package com.parhamvpn.app.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.parhamvpn.app.util.AppLog

/**
 * Keystore-backed EncryptedSharedPreferences. If it cannot be created on this device we fall back to
 * private (UNENCRYPTED) preferences and expose [encrypted] = false so the UI never claims encryption.
 */
class SecureStore(ctx: Context) {
    val encrypted: Boolean
    private val prefs: SharedPreferences

    init {
        var p: SharedPreferences? = null
        var enc = false
        try {
            val key = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            p = EncryptedSharedPreferences.create(
                ctx, "parham_secure", key,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
            enc = true
        } catch (e: Exception) {
            AppLog.e("Encrypted storage unavailable: ${e.javaClass.simpleName}")
        }
        prefs = p ?: ctx.getSharedPreferences("parham_plain", Context.MODE_PRIVATE)
        encrypted = enc
    }

    fun read(): String? = try { prefs.getString("data", null) } catch (e: Exception) { null }
    fun write(json: String) { prefs.edit().putString("data", json).apply() }
}
