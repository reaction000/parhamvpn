package com.parhamvpn.app.ui

import android.content.ClipboardManager
import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.zxing.BinaryBitmap
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.qrcode.QRCodeReader
import com.parhamvpn.app.ParhamApp
import com.parhamvpn.app.R
import com.parhamvpn.app.model.ImportResult
import com.parhamvpn.app.parser.LinkParser
import com.parhamvpn.app.parser.ParseException
import com.parhamvpn.app.parser.SubscriptionDecoder
import com.parhamvpn.app.parser.SubscriptionFetcher
import com.parhamvpn.app.util.AppLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AddServerActivity : AppCompatActivity() {
    private val repo by lazy { (application as ParhamApp).repo }
    private lateinit var etLinks: EditText
    private lateinit var tvResult: TextView

    private val pickQr = registerForActivityResult(ActivityResultContracts.GetContent()) { uri -> uri?.let { readQr(it) } }
    private val pickFile = registerForActivityResult(ActivityResultContracts.GetContent()) { uri -> uri?.let { readFile(it) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add)
        etLinks = findViewById(R.id.etLinks); tvResult = findViewById(R.id.tvResult)
        findViewById<Button>(R.id.btnAddLinks).setOnClickListener { importText(etLinks.text.toString()) }
        findViewById<Button>(R.id.btnPaste).setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
            etLinks.setText(t)
        }
        findViewById<Button>(R.id.btnQr).setOnClickListener { pickQr.launch("image/*") }
        findViewById<Button>(R.id.btnFile).setOnClickListener { pickFile.launch("text/*") }
        findViewById<Button>(R.id.btnAddSub).setOnClickListener { addSubscription() }
    }

    private fun report(r: ImportResult) {
        val added = repo.addAll(r.servers)
        tvResult.text = when {
            r.servers.isEmpty() -> getString(R.string.nothing_added, r.errors.joinToString("\n").ifEmpty { "-" })
            r.errors.isEmpty() -> getString(R.string.added_count, added)
            else -> getString(R.string.added_with_errors, added, r.errors.size, r.errors.joinToString("\n"))
        }
        if (added > 0) etLinks.setText("")
    }

    private fun importText(text: String) = report(LinkParser.parseMany(text))

    private fun readFile(uri: Uri) {
        lifecycleScope.launch {
            val text = withContext(Dispatchers.IO) {
                try {
                    contentResolver.openInputStream(uri)?.use { it.readBytes().take(1_000_000).toByteArray().toString(Charsets.UTF_8) }
                } catch (e: Exception) { null }
            }
            if (text == null) UiUtil.toast(this@AddServerActivity, getString(R.string.file_read_error)) else importText(text)
        }
    }

    private fun readQr(uri: Uri) {
        lifecycleScope.launch {
            val text = withContext(Dispatchers.Default) {
                try {
                    val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
                    val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return@withContext null
                    val px = IntArray(bmp.width * bmp.height)
                    bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
                    QRCodeReader().decode(BinaryBitmap(HybridBinarizer(RGBLuminanceSource(bmp.width, bmp.height, px)))).text
                } catch (e: Exception) { null }
            }
            if (text == null) UiUtil.toast(this@AddServerActivity, getString(R.string.qr_not_found)) else importText(text)
        }
    }

    private fun addSubscription() {
        val url = findViewById<EditText>(R.id.etSubUrl).text.toString().trim()
        val name = findViewById<EditText>(R.id.etSubName).text.toString().trim()
        tvResult.setText(R.string.updating)
        lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.IO) { SubscriptionDecoder.parseBody(SubscriptionFetcher.fetch(url)) }
                val sub = repo.addSubscription(name, url)
                repo.applyUpdate(sub.id, result.servers)
                tvResult.text = getString(R.string.sub_added, result.servers.size)
            } catch (e: ParseException) {
                tvResult.text = getString(R.string.sub_update_failed, e.message)
            } catch (e: Exception) {
                AppLog.e("subscription add failed: ${e.javaClass.simpleName}")
                tvResult.text = getString(R.string.sub_update_failed, e.javaClass.simpleName)
            }
        }
    }
}
