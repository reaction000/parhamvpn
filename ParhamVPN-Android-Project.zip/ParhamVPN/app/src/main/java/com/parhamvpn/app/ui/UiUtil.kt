package com.parhamvpn.app.ui

import android.content.Context
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.parhamvpn.app.R

object UiUtil {
    fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()

    fun input(ctx: Context, title: String, initial: String, onOk: (String) -> Unit) {
        val et = EditText(ctx).apply { setText(initial); setSelection(text.length); setPadding(48, 32, 48, 32) }
        AlertDialog.Builder(ctx).setTitle(title).setView(et)
            .setPositiveButton(R.string.ok) { _, _ -> onOk(et.text.toString()) }
            .setNegativeButton(R.string.cancel, null).show()
    }

    fun confirm(ctx: Context, title: String, onOk: () -> Unit) {
        AlertDialog.Builder(ctx).setTitle(title)
            .setPositiveButton(R.string.ok) { _, _ -> onOk() }
            .setNegativeButton(R.string.cancel, null).show()
    }
}
