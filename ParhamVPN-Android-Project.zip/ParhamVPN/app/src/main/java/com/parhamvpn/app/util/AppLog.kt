package com.parhamvpn.app.util

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Local-only, redacted log file. Used from both app processes. */
object AppLog {
    private var file: File? = null
    private const val MAX_BYTES = 256 * 1024

    fun init(ctx: Context) { file = File(ctx.filesDir, "app.log") }

    @Synchronized
    fun log(level: String, msg: String) {
        val f = file ?: return
        try {
            if (f.length() > MAX_BYTES) f.writeText("")
            val ts = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            f.appendText("$ts $level ${Redactor.redact(msg)}\n")
        } catch (_: Exception) { }
    }

    fun i(msg: String) = log("I", msg)
    fun e(msg: String) = log("E", msg)

    @Synchronized
    fun read(): String = try { file?.takeIf { it.exists() }?.readText().orEmpty() } catch (_: Exception) { "" }

    @Synchronized
    fun clear() { try { file?.writeText("") } catch (_: Exception) { } }
}
