package com.parhamvpn.app.data

import android.content.Context
import com.parhamvpn.app.model.Protocol
import com.parhamvpn.app.model.ServerConfig
import com.parhamvpn.app.model.Subscription
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** All servers/subscriptions live in one JSON blob inside the (encrypted when possible) store. */
class ServerRepository(ctx: Context) {
    private val store = SecureStore(ctx)
    private val lock = Any()
    private var servers = mutableListOf<ServerConfig>()
    private var subs = mutableListOf<Subscription>()
    private var selectedId: String? = null

    val encrypted: Boolean get() = store.encrypted

    init { load() }

    private fun load() = synchronized(lock) {
        val raw = store.read() ?: return@synchronized
        try {
            val o = JSONObject(raw)
            selectedId = o.optString("selected").ifEmpty { null }
            val sa = o.optJSONArray("servers") ?: JSONArray()
            for (i in 0 until sa.length()) {
                val s = sa.getJSONObject(i)
                val pj = s.optJSONObject("params") ?: JSONObject()
                val params = mutableMapOf<String, String>()
                pj.keys().forEach { k -> params[k] = pj.optString(k) }
                servers += ServerConfig(
                    s.getString("id"), s.getString("name"), Protocol.valueOf(s.getString("protocol")),
                    s.getString("host"), s.getInt("port"), s.optString("secret"), params,
                    s.getString("raw"), s.optBoolean("fav"), s.optString("sub").ifEmpty { null }
                )
            }
            val ba = o.optJSONArray("subs") ?: JSONArray()
            for (i in 0 until ba.length()) {
                val b = ba.getJSONObject(i)
                subs += Subscription(b.getString("id"), b.getString("name"), b.getString("url"), b.optLong("last"))
            }
        } catch (e: Exception) {
            servers.clear(); subs.clear(); selectedId = null
        }
    }

    private fun persist() {
        val o = JSONObject()
        o.put("selected", selectedId ?: "")
        o.put("servers", JSONArray().also { arr ->
            servers.forEach { s ->
                arr.put(JSONObject().put("id", s.id).put("name", s.name).put("protocol", s.protocol.name)
                    .put("host", s.host).put("port", s.port).put("secret", s.secret)
                    .put("params", JSONObject(s.params)).put("raw", s.rawLink).put("fav", s.favorite)
                    .put("sub", s.subscriptionId ?: ""))
            }
        })
        o.put("subs", JSONArray().also { arr ->
            subs.forEach { b -> arr.put(JSONObject().put("id", b.id).put("name", b.name).put("url", b.url).put("last", b.lastUpdate)) }
        })
        store.write(o.toString())
    }

    fun servers(): List<ServerConfig> = synchronized(lock) { servers.sortedByDescending { it.favorite } }
    fun subscriptions(): List<Subscription> = synchronized(lock) { subs.toList() }
    fun serverCount(subId: String): Int = synchronized(lock) { servers.count { it.subscriptionId == subId } }
    fun selected(): ServerConfig? = synchronized(lock) { servers.firstOrNull { it.id == selectedId } }

    fun select(id: String) = synchronized(lock) { selectedId = id; persist() }

    /** Adds manual servers, skipping exact duplicates of already-saved manual links. Returns added count. */
    fun addAll(list: List<ServerConfig>): Int = synchronized(lock) {
        var added = 0
        for (s in list) {
            if (servers.any { it.subscriptionId == null && it.rawLink == s.rawLink }) continue
            servers += s.copy(subscriptionId = null); added++
        }
        if (selectedId == null) servers.firstOrNull()?.let { selectedId = it.id }
        persist(); added
    }

    fun delete(id: String) = synchronized(lock) {
        servers.removeAll { it.id == id }
        if (selectedId == id) selectedId = servers.firstOrNull()?.id
        persist()
    }

    fun duplicate(id: String) = synchronized(lock) {
        val s = servers.firstOrNull { it.id == id } ?: return@synchronized
        servers += s.copy(id = UUID.randomUUID().toString(), name = s.name + " (کپی)", favorite = false, subscriptionId = null)
        persist()
    }

    fun toggleFavorite(id: String) = synchronized(lock) {
        servers = servers.map { if (it.id == id) it.copy(favorite = !it.favorite) else it }.toMutableList(); persist()
    }

    fun rename(id: String, name: String) = synchronized(lock) {
        if (name.isBlank()) return@synchronized
        servers = servers.map { if (it.id == id) it.copy(name = name.trim()) else it }.toMutableList(); persist()
    }

    fun addSubscription(name: String, url: String): Subscription = synchronized(lock) {
        val s = Subscription(UUID.randomUUID().toString(), name.ifBlank { "اشتراک" }, url.trim())
        subs += s; persist(); s
    }

    fun renameSubscription(id: String, name: String) = synchronized(lock) {
        if (name.isBlank()) return@synchronized
        subs = subs.map { if (it.id == id) it.copy(name = name.trim()) else it }.toMutableList(); persist()
    }

    fun deleteSubscription(id: String) = synchronized(lock) {
        subs.removeAll { it.id == id }
        servers.removeAll { it.subscriptionId == id }
        if (servers.none { it.id == selectedId }) selectedId = servers.firstOrNull()?.id
        persist()
    }

    /** Replace a subscription's servers ONLY after a successful fetch+parse; favorites/selection kept by raw link. */
    fun applyUpdate(subId: String, fresh: List<ServerConfig>) = synchronized(lock) {
        val old = servers.filter { it.subscriptionId == subId }
        val favLinks = old.filter { it.favorite }.map { it.rawLink }.toSet()
        val selectedRaw = old.firstOrNull { it.id == selectedId }?.rawLink
        servers.removeAll { it.subscriptionId == subId }
        val tagged = fresh.map { it.copy(subscriptionId = subId, favorite = it.rawLink in favLinks) }
        servers.addAll(tagged)
        if (selectedRaw != null) tagged.firstOrNull { it.rawLink == selectedRaw }?.let { selectedId = it.id }
        if (servers.none { it.id == selectedId }) selectedId = servers.firstOrNull()?.id
        subs = subs.map { if (it.id == subId) it.copy(lastUpdate = System.currentTimeMillis()) else it }.toMutableList()
        persist()
    }
}
