package com.parhamvpn.app.util

/** Removes secrets (UUIDs, share links, long tokens, URLs) from log text. */
object Redactor {
    private val uuid = Regex("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")
    private val link = Regex("[a-zA-Z][a-zA-Z0-9+.-]*://\\S+")
    private val token = Regex("[A-Za-z0-9+/_=-]{32,}")
    private val kv = Regex("(?i)\\b(password|pass|pbk|sid|token|key)\\b\"?\\s*[:=]\\s*\"?[^\",\\s}]+")

    fun redact(text: String): String =
        text.replace(link, "[redacted-link]")
            .replace(uuid, "[redacted-id]")
            .replace(kv) { m -> m.groupValues[1] + "=[redacted]" }
            .replace(token, "[redacted]")
}
