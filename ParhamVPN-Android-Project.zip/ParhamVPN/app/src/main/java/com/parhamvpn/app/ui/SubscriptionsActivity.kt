package com.parhamvpn.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.parhamvpn.app.ParhamApp
import com.parhamvpn.app.R
import com.parhamvpn.app.model.Subscription
import com.parhamvpn.app.parser.ParseException
import com.parhamvpn.app.parser.SubscriptionDecoder
import com.parhamvpn.app.parser.SubscriptionFetcher
import com.parhamvpn.app.util.AppLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

class SubscriptionsActivity : AppCompatActivity() {
    private val repo by lazy { (application as ParhamApp).repo }
    private val adapter = Adapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)
        findViewById<TextView>(R.id.tvTitle).setText(R.string.subscriptions)
        findViewById<Button>(R.id.btnAdd).apply {
            setText(R.string.add_subscription)
            setOnClickListener { startActivity(Intent(this@SubscriptionsActivity, AddServerActivity::class.java)) }
        }
        findViewById<TextView>(R.id.tvEmpty).setText(R.string.no_subs_yet)
        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@SubscriptionsActivity); adapter = this@SubscriptionsActivity.adapter
        }
    }

    override fun onResume() { super.onResume(); reload() }

    private fun reload() {
        val subs = repo.subscriptions()
        adapter.submit(subs)
        findViewById<View>(R.id.tvEmpty).visibility = if (subs.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun update(sub: Subscription) {
        val status = findViewById<TextView>(R.id.tvStatus)
        status.visibility = View.VISIBLE; status.setText(R.string.updating)
        lifecycleScope.launch {
            try {
                val res = withContext(Dispatchers.IO) { SubscriptionDecoder.parseBody(SubscriptionFetcher.fetch(sub.url)) }
                repo.applyUpdate(sub.id, res.servers)
                status.text = getString(R.string.sub_updated, res.servers.size)
            } catch (e: ParseException) {
                status.text = getString(R.string.sub_update_failed, e.message)   // old data untouched
            } catch (e: Exception) {
                AppLog.e("subscription update failed: ${e.javaClass.simpleName}")
                status.text = getString(R.string.sub_update_failed, e.javaClass.simpleName)
            }
            reload()
        }
    }

    private inner class Adapter : RecyclerView.Adapter<Adapter.VH>() {
        private var items: List<Subscription> = emptyList()
        fun submit(l: List<Subscription>) { items = l; notifyDataSetChanged() }

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val name: TextView = v.findViewById(R.id.tvName)
            val meta: TextView = v.findViewById(R.id.tvMeta)
            val up: Button = v.findViewById(R.id.btnUpdate)
            val ren: Button = v.findViewById(R.id.btnRename)
            val del: Button = v.findViewById(R.id.btnDelete)
        }

        override fun onCreateViewHolder(p: ViewGroup, t: Int) =
            VH(LayoutInflater.from(p.context).inflate(R.layout.item_sub, p, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, pos: Int) {
            val s = items[pos]
            h.name.text = s.name
            val last = if (s.lastUpdate == 0L) getString(R.string.never)
            else DateFormat.getDateTimeInstance().format(Date(s.lastUpdate))
            h.meta.text = getString(R.string.sub_meta, repo.serverCount(s.id), last)
            h.up.setOnClickListener { update(s) }
            h.ren.setOnClickListener { UiUtil.input(this@SubscriptionsActivity, getString(R.string.rename), s.name) { n -> repo.renameSubscription(s.id, n); reload() } }
            h.del.setOnClickListener { UiUtil.confirm(this@SubscriptionsActivity, getString(R.string.confirm_delete)) { repo.deleteSubscription(s.id); reload() } }
        }
    }
}
