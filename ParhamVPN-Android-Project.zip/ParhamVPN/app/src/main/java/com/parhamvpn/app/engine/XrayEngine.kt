package com.parhamvpn.app.engine

import java.io.File

/** Abstraction over the Xray core wrapper so wrapper API changes stay in one place. */
interface XrayEngine {
    /** True only if the native wrapper class is present in the APK. Must NOT load native code. */
    fun isAvailable(): Boolean
    /** Core version string if the wrapper reports one (loads native code). */
    fun version(): String?
    /** Start the core with a full Xray JSON config. Blocks until started or failed. */
    fun start(configJson: String, workDir: File): Result<Unit>
    fun stop()
}
