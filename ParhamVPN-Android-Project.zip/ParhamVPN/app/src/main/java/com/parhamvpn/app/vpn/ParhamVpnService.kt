package com.parhamvpn.app.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.system.ErrnoException
import android.system.Os
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.parhamvpn.app.R
import com.parhamvpn.app.engine.LibXrayEngine
import com.parhamvpn.app.engine.XrayEngine
import com.parhamvpn.app.ui.MainActivity
import com.parhamvpn.app.util.AppLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Runs in the ":vpn" process. Lifecycle: ACTION_CONNECT -> foreground notification -> check engine ->
 * establish TUN -> export fd via env "xray.tun.fd" -> start core -> CONNECTED. Any failure cleans up
 * and reports ERROR. The process is killed after each session so the next connection starts a fresh
 * Go runtime (the TUN fd env var is only read when the library initialises).
 *
 * Routing-loop prevention: this app is excluded from the VPN (addDisallowedApplication), so the core's
 * own outbound sockets bypass the tunnel. VpnService.protect() is NOT wired because libXray exposes
 * no socket-protect hook that we could verify.
 */
class ParhamVpnService : VpnService() {
    private val engine: XrayEngine = LibXrayEngine()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var tun: ParcelFileDescriptor? = null
    private var engineStarted = false
    private var state = VpnState.DISCONNECTED
    private var message = ""
    private var since = 0L
    private var serverName = ""
    private val main = Handler(Looper.getMainLooper())

    private val queryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { broadcastState() }
    }

    override fun onCreate() {
        super.onCreate()
        AppLog.init(this)
        val ch = NotificationChannel(CHANNEL, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        ContextCompat.registerReceiver(this, queryReceiver, IntentFilter(VpnState.ACTION_QUERY), ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            VpnState.ACTION_CONNECT -> {
                val cfg = intent.getStringExtra(VpnState.EXTRA_CONFIG)
                val dns = intent.getStringArrayListExtra(VpnState.EXTRA_DNS) ?: arrayListOf("1.1.1.1")
                serverName = intent.getStringExtra(VpnState.EXTRA_NAME).orEmpty()
                promoteToForeground()
                if (cfg.isNullOrEmpty()) { fail(getString(R.string.err_no_config)); return START_NOT_STICKY }
                if (job?.isActive == true) return START_NOT_STICKY
                job = scope.launch { connect(cfg, dns) }
            }
            VpnState.ACTION_DISCONNECT -> disconnect()
            else -> if (state == VpnState.DISCONNECTED) { stopSelf(); killSoon() }
        }
        return START_NOT_STICKY
    }

    private fun promoteToForeground() {
        val n = notification(getString(R.string.state_connecting))
        if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED)
        else startForeground(NOTIF_ID, n)
    }

    private fun connect(configJson: String, dns: List<String>) {
        update(VpnState.CONNECTING, "")
        AppLog.i("connect requested")
        if (!engine.isAvailable()) { fail(getString(R.string.err_engine_missing)); return }

        val b = Builder()
            .setSession("Parham VPN")
            .setMtu(1500)
            .addAddress("172.19.0.1", 30)
            .addAddress("fdfe:dcba:9876::1", 126)
            .addRoute("0.0.0.0", 0)
            .addRoute("::", 0)
            .setBlocking(false)
        dns.forEach { try { b.addDnsServer(it) } catch (_: IllegalArgumentException) { } }
        try { b.addDisallowedApplication(packageName) } catch (e: Exception) {
            fail(getString(R.string.err_loop_guard)); return
        }
        val pfd = try { b.establish() } catch (e: Exception) { null }
        if (pfd == null) { fail(getString(R.string.err_establish)); return }
        tun = pfd

        try { Os.setenv("xray.tun.fd", pfd.fd.toString(), true) } catch (e: ErrnoException) {
            fail(getString(R.string.err_tun_fd)); return
        }
        val r = engine.start(configJson, filesDir)
        if (r.isFailure) { fail(getString(R.string.err_engine_start, r.exceptionOrNull()?.message ?: "")); return }
        engineStarted = true
        since = System.currentTimeMillis()
        update(VpnState.CONNECTED, "")
        AppLog.i("connected")
    }

    private fun fail(msg: String) {
        AppLog.e("failure: $msg")
        cleanup()
        update(VpnState.ERROR, msg)
        main.post { finish() }
    }

    private fun disconnect() {
        scope.launch {
            cleanup()
            update(VpnState.DISCONNECTED, "")
            AppLog.i("disconnected")
            main.post { finish() }
        }
    }

    private fun cleanup() {
        if (engineStarted) { engine.stop(); engineStarted = false }
        try { tun?.close() } catch (_: Exception) { }
        tun = null
    }

    private fun finish() {
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        killSoon()
    }

    private fun killSoon() {
        main.postDelayed({ android.os.Process.killProcess(android.os.Process.myPid()) }, 700)
    }

    override fun onRevoke() {
        AppLog.i("VPN permission revoked")
        disconnect()
    }

    override fun onDestroy() {
        try { unregisterReceiver(queryReceiver) } catch (_: Exception) { }
        cleanup()
        job?.cancel()
        scope.cancel()
        super.onDestroy()
    }

    private fun update(s: String, msg: String) {
        state = s; message = msg
        if (s != VpnState.CONNECTED) since = 0L
        broadcastState()
        if (s == VpnState.CONNECTED || s == VpnState.CONNECTING) {
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, notification(
                if (s == VpnState.CONNECTED) getString(R.string.state_connected) else getString(R.string.state_connecting)))
        }
    }

    private fun broadcastState() {
        sendBroadcast(Intent(VpnState.ACTION_STATE).setPackage(packageName)
            .putExtra(VpnState.EXTRA_STATE, state).putExtra(VpnState.EXTRA_MESSAGE, message).putExtra(VpnState.EXTRA_SINCE, since))
    }

    private fun notification(text: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1,
            Intent(this, ParhamVpnService::class.java).setAction(VpnState.ACTION_DISCONNECT), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_logo_small)
            .setContentTitle("Parham VPN")
            .setContentText(if (serverName.isNotEmpty()) "$text • $serverName" else text)
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, getString(R.string.disconnect), stop)
            .build()
    }

    companion object {
        private const val CHANNEL = "vpn_status"
        private const val NOTIF_ID = 1
    }
}
