package com.parhamvpn.app.util

import java.util.Base64

object Base64Util {
    /** Lenient decode: accepts URL-safe alphabet, whitespace and missing padding. Null if invalid. */
    fun decode(input: String): ByteArray? {
        var s = input.filterNot { it.isWhitespace() }.replace('-', '+').replace('_', '/')
        s = s.trimEnd('=')
        if (s.isEmpty() || s.length % 4 == 1) return null
        s += "=".repeat((4 - s.length % 4) % 4)
        return try { Base64.getDecoder().decode(s) } catch (e: IllegalArgumentException) { null }
    }

    fun decodeToString(input: String): String? {
        val b = decode(input) ?: return null
        val dec = Charsets.UTF_8.newDecoder()
            .onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
            .onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT)
        return try { dec.decode(java.nio.ByteBuffer.wrap(b)).toString() } catch (e: java.nio.charset.CharacterCodingException) { null }
    }
}
