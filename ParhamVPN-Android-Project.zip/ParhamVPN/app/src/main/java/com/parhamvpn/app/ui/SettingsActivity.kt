package com.parhamvpn.app.ui

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.parhamvpn.app.ParhamApp
import com.parhamvpn.app.R
import com.parhamvpn.app.data.AppSettings
import com.parhamvpn.app.util.AppLog

class SettingsActivity : AppCompatActivity() {
    private lateinit var settings: AppSettings
    private lateinit var etDns: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        settings = AppSettings(this)
        etDns = findViewById(R.id.etDns)

        val rgTheme = findViewById<RadioGroup>(R.id.rgTheme)
        rgTheme.check(when (settings.theme) { "light" -> R.id.rbLight; "system" -> R.id.rbSystem; else -> R.id.rbDark })
        rgTheme.setOnCheckedChangeListener { _, id ->
            settings.theme = when (id) { R.id.rbLight -> "light"; R.id.rbSystem -> "system"; else -> "dark" }
            AppCompatDelegate.setDefaultNightMode(settings.nightMode())
        }

        val rgDns = findViewById<RadioGroup>(R.id.rgDns)
        rgDns.check(when (settings.dns) { "google" -> R.id.rbGoogle; "quad9" -> R.id.rbQuad9; "custom" -> R.id.rbCustom; else -> R.id.rbCf })
        etDns.setText(settings.customDns)
        rgDns.setOnCheckedChangeListener { _, id ->
            settings.dns = when (id) { R.id.rbGoogle -> "google"; R.id.rbQuad9 -> "quad9"; R.id.rbCustom -> "custom"; else -> "cloudflare" }
        }

        findViewById<Button>(R.id.btnViewLogs).setOnClickListener {
            val t = AppLog.read().ifBlank { getString(R.string.logs_empty) }
            AlertDialog.Builder(this).setTitle(R.string.logs).setMessage(t).setPositiveButton(R.string.ok, null).show()
        }
        findViewById<Button>(R.id.btnClearLogs).setOnClickListener {
            AppLog.clear(); UiUtil.toast(this, getString(R.string.logs_cleared))
        }
        findViewById<TextView>(R.id.tvStorage).setText(
            if ((application as ParhamApp).repo.encrypted) R.string.storage_encrypted else R.string.storage_plain)
    }

    override fun onPause() {
        // Only valid IPv4 entries are used; invalid custom DNS silently falls back to Cloudflare in AppSettings.
        settings.customDns = AppSettings.parseDns(etDns.text.toString()).joinToString(", ")
        super.onPause()
    }
}
