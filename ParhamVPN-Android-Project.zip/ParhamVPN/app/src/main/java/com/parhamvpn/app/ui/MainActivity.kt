package com.parhamvpn.app.ui

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.parhamvpn.app.ParhamApp
import com.parhamvpn.app.R
import com.parhamvpn.app.data.AppSettings
import com.parhamvpn.app.engine.LibXrayEngine
import com.parhamvpn.app.engine.XrayConfigBuilder
import com.parhamvpn.app.vpn.ParhamVpnService
import com.parhamvpn.app.vpn.VpnState

class MainActivity : AppCompatActivity() {
    private lateinit var tvState: TextView
    private lateinit var tvHint: TextView
    private lateinit var tvElapsed: TextView
    private lateinit var tvError: TextView
    private lateinit var tvEngine: TextView
    private lateinit var tvServerName: TextView
    private lateinit var tvServerMeta: TextView
    private lateinit var btnConnect: ImageButton
    private lateinit var ring: View

    private var state = VpnState.DISCONNECTED
    private var since = 0L
    private var lastReply = 0L
    private var queryAt = 0L
    private var pulse: ObjectAnimator? = null
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() { updateElapsed(); handler.postDelayed(this, 1000) }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            lastReply = SystemClock.elapsedRealtime()
            apply(i.getStringExtra(VpnState.EXTRA_STATE) ?: VpnState.DISCONNECTED,
                i.getStringExtra(VpnState.EXTRA_MESSAGE).orEmpty(), i.getLongExtra(VpnState.EXTRA_SINCE, 0L))
        }
    }

    private val vpnPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK) startVpn() else apply(VpnState.ERROR, getString(R.string.vpn_permission_denied), 0L)
    }
    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvState = findViewById(R.id.tvState); tvHint = findViewById(R.id.tvHint)
        tvElapsed = findViewById(R.id.tvElapsed); tvError = findViewById(R.id.tvError)
        tvEngine = findViewById(R.id.tvEngine); tvServerName = findViewById(R.id.tvServerName)
        tvServerMeta = findViewById(R.id.tvServerMeta); btnConnect = findViewById(R.id.btnConnect)
        ring = findViewById(R.id.ring)

        btnConnect.setOnClickListener { onConnectClicked() }
        findViewById<View>(R.id.cardServer).setOnClickListener { open(ServersActivity::class.java) }
        findViewById<Button>(R.id.btnServers).setOnClickListener { open(ServersActivity::class.java) }
        findViewById<Button>(R.id.btnSubs).setOnClickListener { open(SubscriptionsActivity::class.java) }
        findViewById<Button>(R.id.btnSettings).setOnClickListener { open(SettingsActivity::class.java) }
        findViewById<Button>(R.id.btnAbout).setOnClickListener { open(AboutActivity::class.java) }
        findViewById<View>(R.id.rowTelegram).setOnClickListener { openTelegram(this) }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        apply(VpnState.DISCONNECTED, "", 0L)
    }

    override fun onStart() {
        super.onStart()
        ContextCompat.registerReceiver(this, receiver, IntentFilter(VpnState.ACTION_STATE), ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onResume() {
        super.onResume()
        refreshServer()
        tvEngine.text = getString(if (LibXrayEngine().isAvailable()) R.string.engine_ok_banner else R.string.engine_missing_banner)
        // Ask a running service for its state; if nothing answers, assume disconnected.
        queryAt = SystemClock.elapsedRealtime()
        sendBroadcast(Intent(VpnState.ACTION_QUERY).setPackage(packageName))
        handler.postDelayed({
            if (lastReply < queryAt && (state == VpnState.CONNECTED || state == VpnState.CONNECTING))
                apply(VpnState.DISCONNECTED, "", 0L)
        }, 1500)
        handler.post(ticker)
    }

    override fun onPause() { handler.removeCallbacksAndMessages(null); super.onPause() }
    override fun onStop() { try { unregisterReceiver(receiver) } catch (_: Exception) { }; super.onStop() }

    private fun open(c: Class<*>) = startActivity(Intent(this, c))

    private fun refreshServer() {
        val s = (application as ParhamApp).repo.selected()
        if (s == null) { tvServerName.text = getString(R.string.no_server); tvServerMeta.text = "" }
        else { tvServerName.text = s.name; tvServerMeta.text = "${s.protocol.label} • ${s.host}:${s.port}" }
    }

    private fun onConnectClicked() {
        when (state) {
            VpnState.CONNECTED, VpnState.CONNECTING ->
                startService(Intent(this, ParhamVpnService::class.java).setAction(VpnState.ACTION_DISCONNECT))
            else -> {
                if ((application as ParhamApp).repo.selected() == null) {
                    UiUtil.toast(this, getString(R.string.select_server_first)); return
                }
                val prep = VpnService.prepare(this)
                if (prep != null) vpnPermission.launch(prep) else startVpn()
            }
        }
    }

    private fun startVpn() {
        val server = (application as ParhamApp).repo.selected() ?: return
        val config = try { XrayConfigBuilder.build(server) } catch (e: Exception) {
            apply(VpnState.ERROR, e.message.orEmpty(), 0L); return
        }
        apply(VpnState.CONNECTING, "", 0L)
        val i = Intent(this, ParhamVpnService::class.java).setAction(VpnState.ACTION_CONNECT)
            .putExtra(VpnState.EXTRA_CONFIG, config)
            .putExtra(VpnState.EXTRA_DNS, AppSettings(this).dnsServers())
            .putExtra(VpnState.EXTRA_NAME, server.name)
        ContextCompat.startForegroundService(this, i)
    }

    private fun apply(s: String, msg: String, sinceMs: Long) {
        state = s; since = sinceMs
        val on = s == VpnState.CONNECTED
        btnConnect.setBackgroundResource(if (on) R.drawable.bg_connect_on else R.drawable.bg_connect_idle)
        tvState.text = getString(when (s) {
            VpnState.CONNECTED -> R.string.state_connected
            VpnState.CONNECTING -> R.string.state_connecting
            VpnState.ERROR -> R.string.state_error
            else -> R.string.state_disconnected
        })
        tvHint.text = getString(if (s == VpnState.CONNECTED || s == VpnState.CONNECTING) R.string.tap_to_disconnect else R.string.tap_to_connect)
        tvError.visibility = if (s == VpnState.ERROR && msg.isNotEmpty()) View.VISIBLE else View.GONE
        tvError.text = msg
        tvElapsed.visibility = if (on) View.VISIBLE else View.GONE
        if (s == VpnState.CONNECTING) startPulse() else stopPulse()
        updateElapsed()
    }

    private fun updateElapsed() {
        if (state != VpnState.CONNECTED || since == 0L) return
        val sec = ((System.currentTimeMillis() - since) / 1000).coerceAtLeast(0)
        tvElapsed.text = getString(R.string.elapsed, String.format("%02d:%02d:%02d", sec / 3600, (sec % 3600) / 60, sec % 60))
    }

    private fun startPulse() {
        if (pulse != null) return
        pulse = ObjectAnimator.ofFloat(ring, View.ALPHA, 0f, 0.9f, 0f).apply {
            duration = 1400; repeatCount = ValueAnimator.INFINITE; start()
        }
    }

    private fun stopPulse() { pulse?.cancel(); pulse = null; ring.alpha = 0f }

    companion object {
        const val TELEGRAM_URL = "https://t.me/parham_ste01"
        fun openTelegram(ctx: Context) {
            try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(TELEGRAM_URL))) }
            catch (e: Exception) { UiUtil.toast(ctx, TELEGRAM_URL) }
        }
    }
}
