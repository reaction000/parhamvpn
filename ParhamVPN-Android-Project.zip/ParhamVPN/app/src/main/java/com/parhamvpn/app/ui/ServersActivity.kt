package com.parhamvpn.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.PopupMenu
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.parhamvpn.app.ParhamApp
import com.parhamvpn.app.R
import com.parhamvpn.app.model.ServerConfig

class ServersActivity : AppCompatActivity() {
    private val repo by lazy { (application as ParhamApp).repo }
    private val adapter = Adapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)
        findViewById<TextView>(R.id.tvTitle).setText(R.string.servers)
        findViewById<Button>(R.id.btnAdd).apply {
            setText(R.string.add_server)
            setOnClickListener { startActivity(Intent(this@ServersActivity, AddServerActivity::class.java)) }
        }
        findViewById<TextView>(R.id.tvEmpty).setText(R.string.no_servers_yet)
        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@ServersActivity); adapter = this@ServersActivity.adapter
        }
    }

    override fun onResume() { super.onResume(); reload() }

    private fun reload() {
        val items = repo.servers()
        adapter.submit(items, repo.selected()?.id)
        findViewById<View>(R.id.tvEmpty).visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun showMenu(anchor: View, s: ServerConfig) {
        val m = PopupMenu(this, anchor)
        m.menu.add(0, 1, 0, R.string.rename); m.menu.add(0, 2, 1, R.string.duplicate)
        m.menu.add(0, 3, 2, R.string.copy_link); m.menu.add(0, 4, 3, R.string.share_link)
        m.menu.add(0, 5, 4, R.string.delete)
        m.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> UiUtil.input(this, getString(R.string.rename), s.name) { n -> repo.rename(s.id, n); reload() }
                2 -> { repo.duplicate(s.id); reload() }
                3 -> {
                    (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                        .setPrimaryClip(ClipData.newPlainText("link", s.rawLink))
                    UiUtil.toast(this, getString(R.string.copied))
                }
                4 -> startActivity(Intent.createChooser(
                    Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, s.rawLink), null))
                5 -> UiUtil.confirm(this, getString(R.string.confirm_delete)) { repo.delete(s.id); reload() }
            }
            true
        }
        m.show()
    }

    private inner class Adapter : RecyclerView.Adapter<Adapter.VH>() {
        private var items: List<ServerConfig> = emptyList()
        private var selectedId: String? = null

        fun submit(list: List<ServerConfig>, sel: String?) { items = list; selectedId = sel; notifyDataSetChanged() }

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val root: View = v.findViewById(R.id.root)
            val star: TextView = v.findViewById(R.id.tvStar)
            val name: TextView = v.findViewById(R.id.tvName)
            val meta: TextView = v.findViewById(R.id.tvMeta)
            val menu: TextView = v.findViewById(R.id.tvMenu)
        }

        override fun onCreateViewHolder(p: ViewGroup, t: Int) =
            VH(LayoutInflater.from(p.context).inflate(R.layout.item_server, p, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, pos: Int) {
            val s = items[pos]
            h.name.text = s.name
            h.meta.text = "${s.protocol.label} • ${s.host}:${s.port}"
            h.star.text = if (s.favorite) "★" else "☆"
            h.root.setBackgroundResource(if (s.id == selectedId) R.drawable.bg_card_selected else R.drawable.bg_card)
            h.root.setOnClickListener { repo.select(s.id); reload() }
            h.star.setOnClickListener { repo.toggleFavorite(s.id); reload() }
            h.menu.setOnClickListener { showMenu(h.menu, s) }
        }
    }
}
