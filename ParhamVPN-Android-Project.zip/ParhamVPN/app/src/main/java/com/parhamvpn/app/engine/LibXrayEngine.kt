package com.parhamvpn.app.engine

import com.parhamvpn.app.util.AppLog
import com.parhamvpn.app.util.Redactor
import org.json.JSONObject
import java.io.File
import java.lang.reflect.InvocationTargetException
import java.util.Base64

/**
 * Adapter for XTLS/libXray (gomobile class `libXray.LibXray`), used through reflection so the app
 * builds without the AAR and reports "engine unavailable" honestly.
 *
 * UNVERIFIED: written without access to the pinned libXray build. The libXray API has changed
 * between releases (older: runXray(datDir, configPath, maxMemory); newer: runXray(base64Request)
 * returning a base64 JSON {success,data,err}). Both shapes are attempted. Verify against the
 * exact libXray tag you build and adjust here if needed.
 */
class LibXrayEngine : XrayEngine {
    private val className = "libXray.LibXray"
    private var configFile: File? = null

    override fun isAvailable(): Boolean = try {
        Class.forName(className, false, javaClass.classLoader); true
    } catch (e: ClassNotFoundException) { false } catch (e: LinkageError) { false }

    private fun cls(): Class<*> = Class.forName(className)

    override fun version(): String? = try {
        val raw = cls().getMethod("xrayVersion").invoke(null) as? String
        val (ok, payload) = unwrap(raw)
        if (ok || payload.isNotEmpty()) payload.ifEmpty { raw } else raw
    } catch (t: Throwable) { null }

    override fun start(configJson: String, workDir: File): Result<Unit> {
        if (!isAvailable()) return Result.failure(IllegalStateException("libXray.aar نصب نیست"))
        return try {
            val cfg = File(workDir, "xray_config.json").also { configFile = it }
            cfg.writeText(configJson)
            val c = cls()
            val one = c.methods.firstOrNull { it.name == "runXray" && it.parameterTypes.size == 1 && it.parameterTypes[0] == String::class.java }
            val three = c.methods.firstOrNull { it.name == "runXray" && it.parameterTypes.size == 3 }
            val raw: String? = when {
                one != null -> {
                    val req = JSONObject().put("datDir", workDir.absolutePath).put("configPath", cfg.absolutePath).put("maxMemory", 0)
                    one.invoke(null, Base64.getEncoder().encodeToString(req.toString().toByteArray())) as? String
                }
                three != null -> three.invoke(null, workDir.absolutePath, cfg.absolutePath, 0L) as? String
                else -> return Result.failure(IllegalStateException("تابع runXray در libXray یافت نشد (نسخهٔ ناسازگار)"))
            }
            val (ok, payload) = unwrap(raw)
            if (ok) Result.success(Unit) else Result.failure(IllegalStateException(Redactor.redact(payload)))
        } catch (e: InvocationTargetException) {
            Result.failure(IllegalStateException(Redactor.redact(e.targetException?.message ?: "خطای موتور")))
        } catch (t: Throwable) {
            Result.failure(IllegalStateException(Redactor.redact(t.message ?: t.javaClass.simpleName)))
        } finally {
            // The config holds credentials: do not leave it on disk longer than needed.
            runCatching { configFile?.delete() }
        }
    }

    override fun stop() {
        try {
            val raw = cls().getMethod("stopXray").invoke(null) as? String
            val (ok, p) = unwrap(raw)
            if (!ok) AppLog.e("stopXray: $p")
        } catch (t: Throwable) {
            AppLog.e("stopXray failed: ${t.javaClass.simpleName}")
        }
        runCatching { configFile?.delete() }
    }

    /** Returns (success, payload). Empty string = success (old API). Base64 JSON with "success" = new API. */
    private fun unwrap(raw: String?): Pair<Boolean, String> {
        if (raw.isNullOrEmpty()) return true to ""
        val json = try { JSONObject(String(Base64.getDecoder().decode(raw))) } catch (e: Exception) { null }
        if (json != null && json.has("success")) {
            val ok = json.optBoolean("success")
            return ok to (if (ok) json.optString("data") else json.optString("err"))
        }
        return false to raw
    }
}
