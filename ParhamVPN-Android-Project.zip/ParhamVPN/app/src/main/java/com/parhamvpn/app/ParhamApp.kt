package com.parhamvpn.app

import android.app.Application
import android.os.Build
import androidx.appcompat.app.AppCompatDelegate
import com.parhamvpn.app.data.AppSettings
import com.parhamvpn.app.data.ServerRepository
import com.parhamvpn.app.util.AppLog

class ParhamApp : Application() {
    /** Lazy: the :vpn process never touches the repository. */
    val repo: ServerRepository by lazy { ServerRepository(this) }

    override fun onCreate() {
        super.onCreate()
        AppLog.init(this)
        val main = if (Build.VERSION.SDK_INT >= 28) getProcessName() == packageName else true
        if (main) AppCompatDelegate.setDefaultNightMode(AppSettings(this).nightMode())
    }
}
