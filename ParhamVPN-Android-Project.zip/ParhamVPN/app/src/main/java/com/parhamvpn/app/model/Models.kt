package com.parhamvpn.app.model

enum class Protocol(val label: String) {
    VLESS("VLESS"), VMESS("VMess"), TROJAN("Trojan"), SHADOWSOCKS("Shadowsocks"), SOCKS("SOCKS")
}

/**
 * A parsed server. [secret] is the UUID / password. [params] holds normalized values:
 * network, security, sni, fp, alpn, path, host, serviceName, mode, flow, pbk, sid, spx,
 * method (Shadowsocks), cipher (VMess), user (SOCKS).
 */
data class ServerConfig(
    val id: String,
    val name: String,
    val protocol: Protocol,
    val host: String,
    val port: Int,
    val secret: String,
    val params: Map<String, String>,
    val rawLink: String,
    val favorite: Boolean = false,
    val subscriptionId: String? = null
)

data class Subscription(
    val id: String,
    val name: String,
    val url: String,
    val lastUpdate: Long = 0L
)

data class ImportResult(val servers: List<ServerConfig>, val errors: List<String>)
