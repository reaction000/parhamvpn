package com.parhamvpn.app.vpn

object VpnState {
    const val ACTION_CONNECT = "com.parhamvpn.app.action.CONNECT"
    const val ACTION_DISCONNECT = "com.parhamvpn.app.action.DISCONNECT"
    const val ACTION_QUERY = "com.parhamvpn.app.action.QUERY"
    const val ACTION_STATE = "com.parhamvpn.app.action.STATE"

    const val EXTRA_CONFIG = "config"
    const val EXTRA_DNS = "dns"
    const val EXTRA_NAME = "name"
    const val EXTRA_STATE = "state"
    const val EXTRA_MESSAGE = "message"
    const val EXTRA_SINCE = "since"

    const val DISCONNECTED = "DISCONNECTED"
    const val CONNECTING = "CONNECTING"
    const val CONNECTED = "CONNECTED"
    const val ERROR = "ERROR"
}
