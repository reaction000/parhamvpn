package com.parhamvpn.app.parser

import com.parhamvpn.app.model.ImportResult
import com.parhamvpn.app.util.Base64Util
import java.net.HttpURLConnection
import java.net.URL

object SubscriptionDecoder {
    /** Plain text with links, or Base64 of such text. Rejects non-UTF-8 / non-subscription content. */
    fun decodeBody(body: String): String {
        val t = body.trim()
        if (t.isEmpty()) throw ParseException("پاسخ اشتراک خالی است")
        if (t.contains("://")) return t
        if (Base64Util.decode(t) == null) throw ParseException("محتوای اشتراک Base64 معتبر نیست")
        val text = Base64Util.decodeToString(t) ?: throw ParseException("محتوای اشتراک UTF-8 معتبر نیست")
        if (!text.contains("://")) throw ParseException("محتوای اشتراک شامل لینک سرور نیست")
        return text
    }

    fun parseBody(body: String): ImportResult {
        val result = LinkParser.parseMany(decodeBody(body))
        if (result.servers.isEmpty()) throw ParseException("هیچ سرور معتبری در اشتراک یافت نشد")
        return result
    }
}

object SubscriptionFetcher {
    private const val MAX_BYTES = 2 * 1024 * 1024

    /** HTTPS only; blocking — call from a background thread. */
    fun fetch(url: String): String {
        val u = try { URL(url.trim()) } catch (e: Exception) { throw ParseException("آدرس اشتراک نامعتبر است") }
        if (u.protocol != "https") throw ParseException("فقط آدرس HTTPS برای اشتراک مجاز است")
        val c = u.openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 15_000
            c.readTimeout = 20_000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "ParhamVPN/1.0")
            val code = c.responseCode
            if (c.url.protocol != "https") throw ParseException("تغییر مسیر به HTTP مجاز نیست")
            if (code !in 200..299) throw ParseException("پاسخ سرور اشتراک: HTTP $code")
            val out = java.io.ByteArrayOutputStream()
            c.inputStream.use { ins ->
                val buf = ByteArray(8192)
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    if (out.size() > MAX_BYTES) throw ParseException("پاسخ اشتراک بیش از حد بزرگ است")
                }
            }
            return String(out.toByteArray(), Charsets.UTF_8)
        } finally { c.disconnect() }
    }
}
