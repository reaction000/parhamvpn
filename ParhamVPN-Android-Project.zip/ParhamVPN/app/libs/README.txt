Put the real libXray.aar here (exact filename: libXray.aar).
Source: https://github.com/XTLS/libXray  (build via the included GitHub Actions workflow
.github/workflows/build-libxray-aar.yml). Record version + SHA-256 in DEPENDENCIES_AND_LICENSES.md.
Without this file the app shows "Engine unavailable" and never fakes a connection.
