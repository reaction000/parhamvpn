# BUILD_NOTES

## What was and was not done in the authoring environment
- The environment had JDK 21 only: **no Gradle, no Android SDK, no network.**
- **No build was run. No unit test was run. No APK exists.** Static checks only (XML well-formedness,
  package/dir match, all `R.string/R.id/R.drawable` references defined, bracket balance).
- Expect to fix a few compile errors on first build; Kotlin was never compiled.

## Toolchain choices (not verified inside Code on the Go)
- AGP 8.1.4, Kotlin plugin 1.9.10, Gradle 8.4, JDK 17 bytecode, compileSdk/targetSdk 34, minSdk 26.
  Chosen as a conservative combination; CoGo's bundled SDK platforms may differ. If CoGo lacks
  `android-34`, lower compileSdk/targetSdk to the installed platform (same number in both places).
- You mentioned CoGo ships Kotlin 1.9.2; the plugin version here is 1.9.10. If sync complains, change the
  plugin line in root `build.gradle.kts` to the version CoGo supports (stay on 1.9.x).
- `gradlew` and `gradle-wrapper.jar` are NOT included (cannot be generated without Gradle). Only
  `gradle/wrapper/gradle-wrapper.properties` is present. If CoGo does not fetch the distribution by itself,
  use CoGo's own Gradle setup.
- No `local.properties` is shipped.

## Opening / building in CoGo
1. Extract the ZIP on the phone.
2. CoGo → Open project → select the extracted `ParhamVPN` folder (the one with `settings.gradle.kts`).
3. Wait for Gradle sync (needs internet the first time).
4. Build `assembleDebug`. Output: `app/build/outputs/apk/debug/app-debug.apk`.
5. Unit tests: `testDebugUnitTest` (never run by me).

## The engine (the critical part)
The ZIP has **no libXray AAR**. Without it the app shows an "engine missing" banner and refuses to connect
("Engine unavailable"); it never simulates a tunnel.
1. On GitHub: fork/upload this project, open **Actions → Build libXray AAR → Run workflow**, enter a libXray
   tag/commit (pin an exact one). The workflow (`.github/workflows/build-libxray-aar.yml`) is UNVERIFIED —
   written from memory of the libXray README, never run.
2. Download the artifact, copy the AAR to `app/libs/libXray.aar`, rebuild.
3. Record version + `sha256sum` in `DEPENDENCIES_AND_LICENSES.md`.
Building Go/NDK on the phone is not recommended and was not verified.

## Known unverified / risky points (read before trusting the VPN)
1. **libXray API.** `LibXrayEngine` calls `libXray.LibXray.runXray/stopXray/xrayVersion` via reflection and
   handles two historical call shapes. It was never run against a real AAR. Adjust `LibXrayEngine.kt` to
   the real API of your tag.
2. **TUN hand-over.** The service creates the TUN, exports the fd as env `xray.tun.fd` (`Os.setenv`) *before*
   the Go library loads, and configures an Xray `tun` inbound. Whether your Xray/libXray build reads the fd
   this way is unverified. The `:vpn` process is killed after every session so the next one gets a fresh Go
   runtime (the env var is read at init).
3. **Loop prevention** uses `addDisallowedApplication(own package)`, not `VpnService.protect()`; libXray
   exposes no verified protect hook. Consequence: the app itself is not tunnelled (subscription refresh
   goes over the normal network).
4. "Connected" means: engine start returned success AND the TUN was established. It does not probe that
   the remote server is reachable.
5. Tunnel start config includes credentials in an Intent extra to a non-exported service in the same app,
   and in a temp file `xray_config.json` in the app's private dir, deleted right after start.

## Limitations (not implemented)
Server latency test, traffic counters, per-app routing, auto-reconnect on network change, Xray-JSON
import, Hysteria2, QR **camera** scanning (only QR-from-image), English UI, TLS-ALPN/other transports
beyond those listed in README_EN.md, Keystore encryption verified only by API use (falls back to plain private
storage if unavailable; Settings shows which).
